# موری استار — اپ اندروید

اپ، یک پوستهٔ WebView است که https://moriistar.ir را باز می‌کند؛ بک‌اند (Flask) همان سرور فعلی شماست و تغییری لازم ندارد.

## ساخت APK
1. Android Studio (نسخهٔ Koala یا جدیدتر) را باز کنید → Open → همین پوشه.
2. صبر کنید Gradle Sync تمام شود.
3. تست: دکمهٔ Run ▶ (روی گوشی یا شبیه‌ساز).
4. خروجی APK: Build → Build APK(s)  (مسیر: app/build/outputs/apk/)
5. برای انتشار (بازار/مایکت/پلی‌استور): Build → Generate Signed Bundle / APK و ساخت keystore.

## تغییر دامنه
در `app/build.gradle.kts` مقدار SITE_URL و SITE_HOST و در AndroidManifest مقدار android:host را عوض کنید.

## امکانات
- پرداخت زرین‌پال/زیبال داخل اپ، بازشدن اپ بانک (intent / deep link)
- دکمهٔ بازگشت، کشیدن برای رفرش، نوار پیشرفت، صفحهٔ آفلاین
- لینک‌های تلگرام/تلفن/ایمیل با اپ مربوطه باز می‌شوند
- User-Agent شامل `MoriiStarApp/1.0.0` است (برای تشخیص اپ در سرور)

## ساخت APK بدون Android Studio (GitHub Actions)
1. یک repository خصوصی در GitHub بسازید و محتوای این پوشه را در آن آپلود کنید.
2. تب Actions ← «Build APK» ← Run workflow.
3. بعد از چند دقیقه، فایل APK در بخش Artifacts همان اجرا قابل دانلود است (نسخهٔ debug برای نصب و تست).
